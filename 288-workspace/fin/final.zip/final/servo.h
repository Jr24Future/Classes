
void servo_init();

int servo_move(float degrees);

int servo_move_fast(float degrees);

void lcd_printservoinfo(int x);

void servo_cal();

void servo_stop();
