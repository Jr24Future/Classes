#define STAR_SPANGLED    0


#warning "Make sure the open interface has been initialized before calling load_songs()." // you may delete this warning
/// Loads some songs over the open interface
void load_songs();
